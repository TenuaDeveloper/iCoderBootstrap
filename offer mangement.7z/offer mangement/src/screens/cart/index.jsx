import Cart from '../../components/layout/cartitems/index'

/**
 * Needs to refector screen in feature
 * @param {*} props 
 * @returns 
 */
const CartPage = (props) => {
  return <Cart {...props} />
}

export default CartPage;