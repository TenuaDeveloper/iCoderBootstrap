import React from 'react';

import './not-found.css';

class Notfound extends React.Component {
  
  render() {
    return (
      <div id="Notfound">
        <p>not-found works!</p>
      </div>
    )
  }
  
}
export default Notfound; 
