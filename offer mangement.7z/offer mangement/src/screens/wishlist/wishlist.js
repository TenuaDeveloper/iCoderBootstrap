import React from 'react';

import './wishlist.css';


const WishList = () => {


  return (
    <div className="container py-5">
      <p className="text-center">My Wish list works!</p>
    </div>
  )


}
export default WishList;