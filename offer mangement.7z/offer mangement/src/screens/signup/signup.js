import React from 'react';

import './signup.css';

class Signup extends React.Component {

  render() {
    return (
      <div className="container py-5">
        <p className="text-center">signup works!</p>
      </div>
    )
  }

}
export default Signup; 
