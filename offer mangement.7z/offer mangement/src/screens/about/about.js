import React from 'react';

import './about.css';

class About extends React.Component {
  render() {
    return (
      <div className="container py-5">
        <p className="text-center">about works!</p>
      </div>
    )
  }
}

export default About;
