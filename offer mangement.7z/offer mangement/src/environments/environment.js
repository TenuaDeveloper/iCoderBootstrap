export const environment = {
  application:
  {
    name: 'iAirport-Marketplace',
    version: '1.0.0',
    bootstrap: 'Bootstrap 5.2.2',
    fontawesome: 'Font Awesome 6.2.0',
  }
};