class Util {
    getBaseUrl() {
      // return "http://localhost";
      // return "http://172.26.35.4"
      // return "http://10.10.10.223";
      // return "http://172.26.35.2";
      // return "http://localhost:8070";
      // return "http://5.195.59.131"
    }
  
    getClientId() {
      return "test";
    }
  
    getClientSecret() {
      return "temp";
    }
  }
  export default new Util();