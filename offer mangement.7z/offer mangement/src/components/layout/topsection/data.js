export default [
    {
      label: 'AI501 | 12.30PM | DEL-BLR',
      flightno: 'AI501',
      time: '12.30PM',
      sourecedest: 'DEL-BLR',
    },
    {
        label: 'EI501 | 11.30PM | HYD-BLR',
        flightno: 'EI501',
        time: '11.30PM',
        sourecedest: 'HYD-BLR',
      },
      {
        label: 'MI501 | 16.30PM | MUM-BLR',
        flightno: 'MI501',
        time: '16.30PM',
        sourecedest: 'MUM-BLR',
      },
   
  ];
  