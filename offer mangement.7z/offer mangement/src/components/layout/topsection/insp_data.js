export default [
    {
      label: 'Paris',
      location: 'Paris'
    },
    {
      label: 'Switzerland',
      location: 'Switzerland'
    },
    {
      label: 'London',
      location: 'London'
    },
    {
      label: 'Cape Town',
      location: 'Cape Town'
    },
    {
      label: 'Barcelona',
      location: 'Barcelona'
    },
];